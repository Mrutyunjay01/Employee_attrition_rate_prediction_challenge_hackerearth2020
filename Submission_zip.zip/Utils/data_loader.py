# -*- coding: utf-8 -*-

import pandas as pd

train_df = pd.read_csv(r'C:\Users\MRUTYUNJAY BISWAL\Desktop\Hacker Earth Machine learning Challenge\Dataset\train.csv')
print(train_df.head())